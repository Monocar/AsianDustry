// asian difficulty - i would've cried too

// ---- tweak these if you want ----
const SHAKE_INTENSITY = 15;      // screen shake when alpha/beta/gamma shoot
const SHAKE_DURATION = 12;
const BURN_DAMAGE_PER_SEC = 1;   // burning damage on alpha/beta/gamma
const EXPLOSION_RADIUS = 4;      // tiles - only blocks this close get hit
const EXPLOSION_DAMAGE = 150;    // damage to each nearby block

const METEOR_INTERVAL = 30;      // seconds between meteor strikes
const METEOR_DELAY = 120;        // ticks of warning before impact (120 = 2 sec)
const METEOR_RADIUS = 3;         // tiles
const METEOR_DAMAGE = 100;       // damage to units inside the circle
const METEOR_COUNT = 3;          // meteors per strike (first one lands on you)

const BLUE_METEOR_INTERVAL = 60; // seconds between blue meteors
const BLUE_METEOR_RADIUS = 4;    // tiles
const BLUE_METEOR_DAMAGE = 40;   // small damage to the player AND every block inside the circle

const TAX_INTERVAL = 120;        // seconds between core taxes
const TAX_PERCENT = 0.10;        // share of ONE random resource the core loses
const DEATH_TAX = 25;            // copper the core loses every time you die

const QUAKE_INTERVAL = 240;      // seconds between earthquakes
const QUAKE_DURATION = 8;        // seconds of shaking (the siren plays at the start)
const QUAKE_BLOCK_CHANCE = 0.10; // chance each block (not cores) is hit when the quake ends
const QUAKE_BLOCK_DAMAGE = 30;
const EFFECT_INTERVAL = 60;      // seconds between random effects on alpha/beta/gamma
const CoreBlockClass = Packages.mindustry.world.blocks.storage.CoreBlock;
const WRONG_DRILL_CHANCE = 0.25; // chance a drilled item becomes sand/scrap instead
const DrillClass = Packages.mindustry.world.blocks.production.Drill;

function isTroll(u){
    return u.type == UnitTypes.alpha || u.type == UnitTypes.beta || u.type == UnitTypes.gamma;
}

// big centered on-screen text
function say(text, seconds){
    if(Vars.headless) return;
    try{
        Vars.ui.announce(text, seconds);
    }catch(e){
        try{ Vars.ui.showInfoToast(text, seconds); }catch(e2){ Log.err(e2); }
    }
}

// in-game background music: all vanilla in-game tracks are removed (menu music is untouched)
// and music/unwelcome-school.ogg loops while you are in a world
var bgMusic = null;
try{
    bgMusic = Vars.tree.loadMusic("unwelcome-school");
}catch(e){ Log.err(e); }

function replaceMusic(){
    try{
        var sc = Vars.control.sound;
        sc.ambientMusic.clear();
        sc.darkMusic.clear();
        sc.bossMusic.clear();
        if(bgMusic != null){
            sc.ambientMusic.add(bgMusic);
            sc.darkMusic.add(bgMusic);
            sc.bossMusic.add(bgMusic);
        }
        // the game never starts its own in-game music, this mod plays the track itself
        sc.musicChance = 0;
        sc.musicWaveChance = 0;
    }catch(e){ Log.err(e); }
}
Events.on(ClientLoadEvent, replaceMusic);
Events.on(WorldLoadEvent, replaceMusic);

// stop the track when going back to the menu
Events.on(StateChangeEvent, e => {
    try{
        if(String(e.to) == "menu" && bgMusic != null) bgMusic.stop();
    }catch(err){ Log.err(err); }
});

// shows the first few script errors on screen so they can be reported
var errShown = 0;
function reportError(where, e){
    try{ Log.err(e); }catch(x){}
    if(errShown < 3 && !Vars.headless){
        errShown++;
        say("[scarlet]AsianDustry error (" + where + "):[] " + e, 8);
    }
}

// sound that plays when you launch into a world (sounds/koyuki.ogg)
var sirenSound = null;
try{
    sirenSound = Vars.tree.loadSound("siren");
}catch(e){ Log.err(e); }

var spawnSound = null;
try{
    spawnSound = Vars.tree.loadSound("koyuki");
}catch(e){ Log.err(e); }

// on-screen text lower down (frac = height from the bottom, 0.5 = center) so messages don't collide
function sayLow(text, seconds, frac){
    if(Vars.headless) return;
    try{
        var A = Packages.arc.scene.actions.Actions;
        var t = new Packages.arc.scene.ui.layout.Table(Packages.mindustry.ui.Styles.black3);
        t.touchable = Packages.arc.scene.event.Touchable.disabled;
        t.margin(8).add(text).style(Packages.mindustry.ui.Styles.outlineLabel).labelAlign(Packages.arc.util.Align.center);
        t.update(() => t.setPosition(Core.graphics.getWidth() / 2, Core.graphics.getHeight() * frac, Packages.arc.util.Align.center));
        t.actions(A.fadeOut(seconds, Packages.arc.math.Interp.pow4In), A.remove());
        Core.scene.add(t);
    }catch(e){
        say(text, seconds);   // fallback: centered text
    }
}

// custom burning status: 1 hp/sec, looks like normal fire
const slowBurn = new StatusEffect("slow-burn");
slowBurn.damage = BURN_DAMAGE_PER_SEC / 60;   // damage is per tick
slowBurn.effect = Fx.burning;
slowBurn.color = Color.valueOf("ffc455");

// meteor warning circle + falling rock (color and size per meteor type)
function makeMeteorFx(hex, hotHex, radiusTiles){
    var rpx = radiusTiles * 8;
    return new Effect(METEOR_DELAY, 500, e => {
        Draw.z(Layer.effect);

        // danger zone
        Draw.color(Color.valueOf(hex), 0.12 + 0.18 * e.fin());
        Fill.circle(e.x, e.y, rpx);
        Draw.color(Color.valueOf(hex), 0.5 + 0.5 * Mathf.absin(Time.time, 6, 1));
        Lines.stroke(2);
        Lines.circle(e.x, e.y, rpx);

        // shadow grows as the rock gets closer
        Draw.color(Color.black, 0.3);
        Fill.circle(e.x, e.y, 6 * e.fin());

        // the falling rock
        var h = (1 - e.fin()) * 300;
        Draw.color(Color.valueOf(hotHex), 0.6);
        Lines.stroke(5);
        Lines.line(e.x, e.y + h, e.x, e.y + h + 40);
        Draw.color(Color.valueOf("4a4a4a"));
        Fill.circle(e.x, e.y + h, 7);
        Draw.color(Color.valueOf(hotHex));
        Fill.circle(e.x, e.y + h, 3.5);
        Draw.reset();
    });
}
const redMeteorFx = makeMeteorFx("ff2020", "ff9020", METEOR_RADIUS);
const blueMeteorFx = makeMeteorFx("2080ff", "60c0ff", BLUE_METEOR_RADIUS);

// one meteor: warning circle now, impact after METEOR_DELAY ticks
function dropMeteor(fx, radiusTiles, damage, hitBlocks, x, y){
    try{
        var rpx = radiusTiles * 8;
        fx.at(x, y);
        Time.run(METEOR_DELAY, () => {
            try{
                try{ Fx.explosion.at(x, y); }catch(e){}
                try{ Effect.shake(5, 15, x, y); }catch(e){}

                // player units inside the circle
                Groups.unit.each(u => {
                    if(!u.dead && u.isPlayer() && u.within(x, y, rpx + u.hitSize / 2)){
                        u.damage(damage);
                    }
                });

                // blocks inside the circle (blue meteor only)
                if(hitBlocks){
                    var targets = new Seq();
                    Vars.indexer.allBuildings(x, y, rpx, b => { targets.add(b); });
                    targets.each(b => { b.damage(damage); });
                }
            }catch(e){ Log.err(e); }
        });
    }catch(e){ Log.err(e); }
}

// red meteors: METEOR_COUNT around each player, units only
function dropRedMeteors(){
    Groups.player.each(p => {
        if(p.dead()) return;
        var pu = p.unit();
        if(pu == null) return;
        var px = pu.x, py = pu.y;
        for(var i = 0; i < METEOR_COUNT; i++){
            var ox = 0, oy = 0;
            if(i > 0){
                var a = Mathf.random(360);
                var d = Mathf.random(5, 9) * 8;
                ox = Mathf.cosDeg(a) * d;
                oy = Mathf.sinDeg(a) * d;
            }
            var mx = px + ox, my = py + oy;
            Time.run(i * 25, () => dropMeteor(redMeteorFx, METEOR_RADIUS, METEOR_DAMAGE, false, mx, my));
        }
    });
}

// blue meteor: one on each player, hits the player and blocks, small damage
function dropBlueMeteors(){
    Groups.player.each(p => {
        if(p.dead()) return;
        var pu = p.unit();
        if(pu == null) return;
        dropMeteor(blueMeteorFx, BLUE_METEOR_RADIUS, BLUE_METEOR_DAMAGE, true, pu.x, pu.y);
    });
}

// alpha/beta/gamma carry 1 item, every wall has 1 health
function applyStats(){
    try{
        [UnitTypes.alpha, UnitTypes.beta, UnitTypes.gamma].forEach(t => {
            t.itemCapacity = 1;
        });
        Vars.content.blocks().each(b => {
            if(b instanceof Packages.mindustry.world.blocks.defense.Wall){
                b.health = 1;
            }
        });
    }catch(e){ Log.err(e); }
}
Events.on(ContentInitEvent, applyStats);
Events.on(ClientLoadEvent, applyStats);

// every water tile (shallow, deep, sand, tainted...) becomes lava (slag)
function waterToLava(){
    try{
        var w = Vars.world.width(), h = Vars.world.height();
        for(var x = 0; x < w; x++){
            for(var y = 0; y < h; y++){
                var t = Vars.world.tile(x, y);
                if(t != null && t.floor().liquidDrop == Liquids.water){
                    t.setFloor(Blocks.slag);
                }
            }
        }
    }catch(e){ Log.err(e); }
}
Events.on(WorldLoadEvent, waterToLava);

// per-world state
var welcomed = false;
var meteorTimer = 0;
var blueTimer = 0;
var taxTimer = 0;
Events.on(WorldLoadEvent, e => {
    welcomed = false;
    meteorTimer = 0;
    blueTimer = 0;
    lastHealth = new ObjectFloatMap();
    lastDrillProgress = new ObjectFloatMap();
    drillReal = new ObjectMap();
    drillAssigned = new ObjectMap();
    wasAliveTax = false;
    lastTeam = null;
    taxTimer = 0;
    quakeTimer = 0;
    quakeLeft = 0;
    effectTimer = 0;
});

var miningWarned = false;
var quakeTimer = 0;
var quakeLeft = 0;
var effectTimer = 0;

// earthquake: siren + long screen shake, then some blocks get cracked
function startQuake(){
    quakeLeft = QUAKE_DURATION * 60;
    try{ if(!Vars.headless && sirenSound != null) sirenSound.play(); }catch(e){ reportError("siren", e); }
    sayLow("[scarlet]EARTHQUAKE![]", 3, 0.41);
}

function endQuake(){
    try{
        var victims = [];
        Groups.build.each(b => {
            if(b.block instanceof CoreBlockClass) return;
            if(Mathf.chance(QUAKE_BLOCK_CHANCE)) victims.push(b);
        });
        victims.forEach(b => { if(b.isValid()) b.damage(QUAKE_BLOCK_DAMAGE); });
    }catch(e){ reportError("earthquake", e); }
}

function quakeFrame(){
    if(!Vars.headless){
        var f = quakeLeft / (QUAKE_DURATION * 60);   // 1 -> 0
        Vars.renderer.shake(3 + 7 * f, 12);
    }
    quakeLeft -= Time.delta;
    if(quakeLeft <= 0){
        quakeLeft = 0;
        endQuake();
    }
}

// random status effect on alpha/beta/gamma
function randomEffects(){
    try{
        var pool = [
            [StatusEffects.fast, 15], [StatusEffects.overdrive, 15], [StatusEffects.overclock, 15],
            [StatusEffects.boss, 15], [StatusEffects.shielded, 15], [StatusEffects.freezing, 15],
            [StatusEffects.wet, 15], [StatusEffects.muddy, 15], [StatusEffects.sapped, 15],
            [StatusEffects.tarred, 15], [StatusEffects.slow, 15], [StatusEffects.melting, 5],
            [StatusEffects.unmoving, 3], [StatusEffects.disarmed, 5], [StatusEffects.invincible, 5]
        ].filter(p => p[0] != null);
        if(pool.length == 0) return;
        Groups.unit.each(u => {
            if(u.dead || !isTroll(u)) return;
            var pick = pool[Math.floor(Math.random() * pool.length)];
            u.apply(pick[0], pick[1] * 60);
            if(!Vars.headless && u == Vars.player.unit()){
                sayLow("[accent]RANDOM EFFECT:[] " + (pick[0].localizedName || pick[0].name), 3, 0.20);
            }
        });
    }catch(e){ reportError("random effect", e); }
}

// the player's team (remembered while alive, because a dead player has no team)
var lastTeam = null;
var wasAliveTax = false;

function playerCore(){
    var t = lastTeam != null ? lastTeam : Vars.state.rules.defaultTeam;
    return t.core();
}

// core tax: the core loses a share of one random resource
function collectTax(){
    try{
        if(Vars.headless || Vars.player == null) return;
        var core = playerCore();
        if(core == null) return;
        var list = [];
        Vars.content.items().each(it => { if(core.items.get(it) > 0) list.push(it); });
        if(list.length == 0) return;
        var item = list[Math.floor(Math.random() * list.length)];
        var amt = Math.max(1, Math.floor(core.items.get(item) * TAX_PERCENT));
        core.items.remove(item, amt);
        sayLow("[gold]TAX COLLECTED:[] -" + amt + " " + item.localizedName, 3, 0.34);
    }catch(e){ reportError("core tax", e); }
}

// death tax: the core pays copper every time the player dies
function deathTax(){
    try{
        var core = playerCore();
        if(core == null) return;
        var n = Math.min(DEATH_TAX, core.items.get(Items.copper));
        if(n > 0 && !Vars.net.client()) core.items.remove(Items.copper, n);
        sayLow(n > 0 ? "[scarlet]DEATH TAX:[] -" + n + " copper"
                     : "[scarlet]DEATH TAX:[] the core is too broke to pay", 3, 0.27);
    }catch(e){ reportError("death tax", e); }
}

// message the first time you place a wall (once per game launch)
var wallMsgShown = false;
Events.on(BlockBuildEndEvent, e => {
    try{
        if(wallMsgShown || e.breaking || e.unit == null) return;
        if(e.team != Vars.player.team() || e.unit != Vars.player.unit()) return;
        if(e.tile.block() instanceof Packages.mindustry.world.blocks.defense.Wall){
            wallMsgShown = true;
            say("[scarlet]we don't fear our enemies[]", 3);
        }
    }catch(err){ Log.err(err); }
});

// ---- images that pop up when a mechanical drill is placed ----
const POP_SHOW = 4;      // seconds fully visible
const POP_FADE = 3;      // seconds of slow fade-out
const POP_GAP = 1;       // seconds between image 1 and image 2
var popActive = 0;

function popImage(spriteName){
    try{
        if(Vars.headless || popActive >= 20) return;
        var region = Core.atlas.find("asian-difficulty-" + spriteName);
        if(region == null || !Core.atlas.isFound(region)) return;

        var sw = Core.scene.getWidth(), sh = Core.scene.getHeight();
        var sz = Math.min(sw, sh) * 0.3;
        var w = sz * (region.width / region.height), h = sz;

        var img = new Packages.arc.scene.ui.Image(region);
        img.setSize(w, h);
        img.setPosition(Mathf.random(0, Math.max(0, sw - w)), Mathf.random(0, Math.max(0, sh - h)));
        img.touchable = Packages.arc.scene.event.Touchable.disabled;   // never blocks taps
        img.color.a = 0;

        popActive++;
        img.actions(
            Packages.arc.scene.actions.Actions.fadeIn(0.2),
            Packages.arc.scene.actions.Actions.delay(POP_SHOW),
            Packages.arc.scene.actions.Actions.fadeOut(POP_FADE),
            Packages.arc.scene.actions.Actions.run(() => { popActive--; }),
            Packages.arc.scene.actions.Actions.remove()
        );
        Core.scene.add(img);
    }catch(e){ Log.err(e); }
}

Events.on(BlockBuildEndEvent, e => {
    try{
        if(e.breaking || e.unit == null) return;
        if(e.team != Vars.player.team() || e.unit != Vars.player.unit()) return;
        if(e.tile.block() == Blocks.mechanicalDrill){
            popImage("dustry1");
            Time.run(POP_GAP * 60, () => popImage("dustry2"));
        }
    }catch(err){ Log.err(err); }
});

// conveyors face the opposite way once built
Events.on(BlockBuildEndEvent, e => {
    try{
        if(e.breaking) return;
        var bd = e.tile.build;
        if(bd == null) return;
        if(!(bd.block instanceof Packages.mindustry.world.blocks.distribution.Conveyor)) return;

        bd.rotation = (bd.rotation + 2) % 4;

        var near = new Seq();
        bd.proximity.each(n => { near.add(n); });
        bd.updateProximity();
        near.each(n => { n.updateProximity(); });
    }catch(err){ Log.err(err); }
});

// small explosion: only damages blocks close by, then kills the unit
function smallBoom(u){
    var x = u.x, y = u.y;
    try{ Fx.explosion.at(x, y); }catch(e){}
    try{ Effect.shake(3, 10, x, y); }catch(e){}
    try{
        var targets = new Seq();
        Vars.indexer.allBuildings(x, y, EXPLOSION_RADIUS * Vars.tilesize, b => { targets.add(b); });
        targets.each(b => { b.damage(EXPLOSION_DAMAGE); });
    }catch(e){ Log.err(e); }
    try{ u.kill(); }catch(e){ Log.err(e); }
}

var lastHealth = new ObjectFloatMap();
var lastDrillProgress = new ObjectFloatMap();
var drillReal = new ObjectMap();       // the item each drill really mines
var drillAssigned = new ObjectMap();   // the item this mod last gave it
var healTick = 0;
var prevBullets = new IntSet();
var mineTimers = {};
var wasMining = {};

Events.run(Trigger.update, () => {
    if(!Vars.state.isGame()) return;

    try{
        // ---- remember the player's team while alive, detect death (alive -> dead) ----
        if(!Vars.headless && Vars.player != null){
            var aliveNow = !Vars.player.dead();
            if(aliveNow) lastTeam = Vars.player.team();
            if(wasAliveTax && !aliveNow) deathTax();
            wasAliveTax = aliveNow;
        }

        // ---- background music: loop while in game, follows the music volume setting ----
        if(!Vars.headless && bgMusic != null){
            try{
                bgMusic.setLooping(true);
                bgMusic.setVolume(Core.settings.getInt("musicvol", 100) / 100);
                if(!bgMusic.isPlaying()) bgMusic.play();
            }catch(e){ Log.err(e); }
        }

        // ---- repair nerf: any block heal gives at most +1 hp (host / singleplayer) ----
        if(!Vars.net.client()){
            healTick++;
            var fresh = (healTick % 300 == 0) ? new ObjectFloatMap() : null;
            var freshProg = (healTick % 300 == 0) ? new ObjectFloatMap() : null;
            var freshReal = (freshProg != null) ? new ObjectMap() : null;
            var freshAssigned = (freshProg != null) ? new ObjectMap() : null;
            Groups.build.each(b => {
                var h = b.health;
                var prev = lastHealth.get(b, h);
                if(h > prev + 1 && !(b.block instanceof Packages.mindustry.world.blocks.ConstructBlock)){
                    h = prev + 1;
                    b.health = h;
                }
                lastHealth.put(b, h);
                if(fresh != null) fresh.put(b, h);

                // wrong drill output: after each item a drill makes, the NEXT one may be sand/scrap
                // (drills hand items straight to conveyors, so we swap what the drill mines instead)
                if(b.block instanceof DrillClass && b.dominantItem != null){
                    try{
                        var cur = b.dominantItem;
                        var assigned = drillAssigned.get(b);
                        var real = drillReal.get(b);
                        if(real == null || assigned == null || cur != assigned){
                            real = cur;                       // the game chose this item itself
                            drillReal.put(b, real);
                        }
                        var pg = b.progress;
                        var lastP = lastDrillProgress.get(b, pg);
                        if(pg < lastP){                        // an item was just produced
                            var next = real;
                            if(Mathf.chance(WRONG_DRILL_CHANCE)){
                                next = Mathf.chance(0.5) ? Items.sand : Items.scrap;
                                if(next == real) next = (next == Items.sand) ? Items.scrap : Items.sand;
                            }
                            b.dominantItem = next;
                            drillAssigned.put(b, next);
                        }
                        lastDrillProgress.put(b, pg);
                        if(freshProg != null){
                            freshProg.put(b, pg);
                            freshReal.put(b, real);
                            var asg = drillAssigned.get(b);
                            if(asg != null) freshAssigned.put(b, asg);
                        }
                    }catch(err){ reportError("drills", err); }
                }
            });
            if(fresh != null) lastHealth = fresh;   // drops buildings that no longer exist
            if(freshProg != null){
                lastDrillProgress = freshProg;
                drillReal = freshReal;
                drillAssigned = freshAssigned;
            }
        }

        // ---- welcome text when the player first spawns in a world ----
        if(!welcomed && !Vars.headless && Vars.player != null && !Vars.player.dead()){
            welcomed = true;
            say("[scarlet]Welcome to hell, sayang[]", 3);
            try{ if(spawnSound != null) spawnSound.play(); }catch(e){ Log.err(e); }
        }

        // ---- red meteors every 30 sec, blue meteor every 60 sec (host / singleplayer) ----
        if(!Vars.state.isPaused() && !Vars.net.client()){
            meteorTimer += Time.delta;
            if(meteorTimer >= METEOR_INTERVAL * 60){
                meteorTimer = 0;
                dropRedMeteors();
            }
            blueTimer += Time.delta;
            if(blueTimer >= BLUE_METEOR_INTERVAL * 60){
                blueTimer = 0;
                dropBlueMeteors();
            }
            taxTimer += Time.delta;
            if(taxTimer >= TAX_INTERVAL * 60){
                taxTimer = 0;
                collectTax();
            }

            quakeTimer += Time.delta;
            if(quakeLeft <= 0 && quakeTimer >= QUAKE_INTERVAL * 60){
                quakeTimer = 0;
                startQuake();
            }
            if(quakeLeft > 0) quakeFrame();

            effectTimer += Time.delta;
            if(effectTimer >= EFFECT_INTERVAL * 60){
                effectTimer = 0;
                randomEffects();
            }
        }

        // ---- bullets: scatter in a random direction (not crux) + shake for alpha/beta/gamma ----
        var next = new IntSet();
        var window = Time.delta * 2.5 + 0.01;
        var shake = false;

        Groups.bullet.each(b => {
            if(b.time > window) return;          // only brand new bullets
            next.add(b.id);
            if(prevBullets.contains(b.id)) return;

            if(b.team != Team.crux){
                var ang = Mathf.random(360);
                b.vel.setAngle(ang);
                b.rotation(ang);
            }

            var o = b.owner;
            if(o instanceof Unit && isTroll(o)) shake = true;
        });
        prevBullets = next;

        if(shake && !Vars.headless){
            Vars.renderer.shake(SHAKE_INTENSITY, SHAKE_DURATION);
        }

        // ---- alpha/beta/gamma: permanent burning, mining warning, explode on mining ----
        var nextTimers = {};
        var nextMining = {};
        var exploders = [];
        Groups.unit.each(u => {
            if(u.dead || !isTroll(u)) return;

            u.apply(slowBurn, 20);

            var mining = u.mineTile != null;
            nextMining[u.id] = mining;

            // warning when the local player starts mining
            if(mining && !wasMining[u.id] && !miningWarned && !Vars.headless && u == Vars.player.unit()){
                miningWarned = true;   // only shown once per game launch
                say("[scarlet]NO MINING ALLOWED WITHOUT GOVERNMENT PERMISSION[]", 2);
            }

            // mineTimer drops back to 0 each time an ore is actually mined
            var last = mineTimers[u.id];
            nextTimers[u.id] = u.mineTimer;
            if(!Vars.net.client() && mining && last !== undefined && u.mineTimer < last){
                exploders.push(u);
            }
        });
        mineTimers = nextTimers;
        wasMining = nextMining;

        // explode after the loop so nothing gets modified mid-iteration
        exploders.forEach(u => smallBoom(u));
    }catch(e){
        reportError("main loop", e);
    }
});

// alpha/beta/gamma get a little red tint
Events.run(Trigger.postDraw, () => {
    if(Vars.headless || !Vars.state.isGame()) return;
    try{
        Groups.unit.each(u => {
            if(u.dead || !isTroll(u)) return;
            Draw.mixcol(Color.valueOf("ff2020"), 0.3);
            Draw.rect(u.type.region, u.x, u.y, u.rotation - 90);
            Draw.mixcol();
        });
    }catch(e){ Log.err(e); }
});


// =====================================================================
// red UI theme (added): black panels stay, white text/accents -> bright red
// change UI_RED to tweak the color
// =====================================================================
const UI_RED = Color.valueOf("ff1a1a");

function isNearWhite(c){
    return c != null && c.r > 0.85 && c.g > 0.85 && c.b > 0.85;
}

// recolors every white-ish *FontColor on a style object (fontColor, overFontColor, etc.)
function redStyle(style){
    if(style == null) return;
    try{
        var fields = style.getClass().getFields();
        for(var i = 0; i < fields.length; i++){
            var f = fields[i];
            if(!/fontcolor/i.test(String(f.getName()))) continue;
            var v = f.get(style);
            if(v == null){
                if(String(f.getName()) == "fontColor") f.set(style, UI_RED.cpy());
            }else if(isNearWhite(v)){
                f.set(style, UI_RED.cpy());
            }
        }
    }catch(e){ /* not a style object, skip */ }
}

function applyRedTheme(){
    try{
        // accent color: dividers, titles, highlights, selected stuff (edited in place so everything that references it follows)
        Packages.mindustry.graphics.Pal.accent.set(UI_RED);
        Packages.mindustry.graphics.Pal.stat.set(UI_RED);
    }catch(e){ Log.err(e); }

    try{
        // every style in Styles (buttons, labels, dialogs, fields, ...)
        var stylesCls = null;
        try{ stylesCls = java.lang.Class.forName("mindustry.ui.Styles"); }catch(e){ stylesCls = Packages.mindustry.ui.Styles.class; }
        var fields = stylesCls.getDeclaredFields();
        for(var i = 0; i < fields.length; i++){
            try{
                fields[i].setAccessible(true);
                redStyle(fields[i].get(null));
            }catch(e){}
        }
    }catch(e){ Log.err(e); }
}
Events.on(ClientLoadEvent, applyRedTheme);
