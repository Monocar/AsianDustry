// asian difficulty - i would've cried too

// ---- tweak these if you want ----
const SHAKE_INTENSITY = 15;      // screen shake when alpha/beta/gamma shoot
const SHAKE_DURATION = 12;
const BURN_DAMAGE_PER_SEC = 1;   // burning damage on alpha/beta/gamma
const EXPLOSION_RADIUS = 4;      // tiles - only blocks this close get hit
const EXPLOSION_DAMAGE = 150;    // damage to each nearby block

const METEOR_INTERVAL = 30;      // seconds between meteor strikes
const METEOR_DELAY = 120;        // ticks of warning before impact (120 = 2 sec)
const METEOR_RADIUS = 3;         // tiles
const METEOR_DAMAGE = 100;       // damage to units inside the circle
const RED_METEOR_BLOCK_DAMAGE = 5; // hp lost by every block inside a red meteor circle
const METEOR_COUNT = 3;          // meteors per strike (first one lands on you)

const BLUE_METEOR_INTERVAL = 60; // seconds between blue meteors
const BLUE_METEOR_RADIUS = 4;    // tiles
const BLUE_METEOR_DAMAGE = 40;   // small damage to the player AND every block inside the circle

const TAX_INTERVAL = 120;        // seconds between core taxes
const TAX_PERCENT = 0.10;        // share of ONE random resource the core loses
const DEATH_TAX = 25;            // copper the core loses every time you die

const QUAKE_INTERVAL = 240;      // seconds between earthquakes
const QUAKE_DURATION = 8;        // seconds of shaking (the siren plays at the start)
const QUAKE_BLOCK_CHANCE = 0.10; // chance each block (not cores) is hit when the quake ends
const QUAKE_BLOCK_DAMAGE = 30;
const EFFECT_INTERVAL = 60;      // seconds between random effects on alpha/beta/gamma
const CoreBlockClass = Packages.mindustry.world.blocks.storage.CoreBlock;
const WRONG_DRILL_CHANCE = 0.25; // chance a drilled item becomes sand/scrap instead
const DrillClass = Packages.mindustry.world.blocks.production.Drill;

function isTroll(u){
    return u.type == UnitTypes.alpha || u.type == UnitTypes.beta || u.type == UnitTypes.gamma;
}

// big centered on-screen text
function say(text, seconds){
    if(Vars.headless) return;
    try{
        Vars.ui.announce(text, seconds);
    }catch(e){
        try{ Vars.ui.showInfoToast(text, seconds); }catch(e2){ Log.err(e2); }
    }
}

// in-game background music: all vanilla in-game tracks are removed (menu music is untouched)
// and music/unwelcome-school.ogg loops while you are in a world
var bgMusic = null;
try{
    bgMusic = Vars.tree.loadMusic("unwelcome-school");
}catch(e){ Log.err(e); }

function replaceMusic(){
    try{
        var sc = Vars.control.sound;
        sc.ambientMusic.clear();
        sc.darkMusic.clear();
        sc.bossMusic.clear();
        if(bgMusic != null){
            sc.ambientMusic.add(bgMusic);
            sc.darkMusic.add(bgMusic);
            sc.bossMusic.add(bgMusic);
        }
        // the game never starts its own in-game music, this mod plays the track itself
        sc.musicChance = 0;
        sc.musicWaveChance = 0;
    }catch(e){ Log.err(e); }
}
Events.on(ClientLoadEvent, replaceMusic);
Events.on(WorldLoadEvent, replaceMusic);

// stop the track when going back to the menu
Events.on(StateChangeEvent, e => {
    try{
        if(String(e.to) == "menu" && bgMusic != null) bgMusic.stop();
    }catch(err){ Log.err(err); }
});

// shows the first few script errors on screen so they can be reported
var errShown = 0;
function reportError(where, e){
    try{ Log.err(e); }catch(x){}
    if(errShown < 3 && !Vars.headless){
        errShown++;
        say("[scarlet]AsianDustry error (" + where + "):[] " + e, 8);
    }
}

// sound that plays when you launch into a world (sounds/koyuki.ogg)
var sirenSound = null;
try{
    sirenSound = Vars.tree.loadSound("siren");
}catch(e){ Log.err(e); }

var spawnSound = null;
try{
    spawnSound = Vars.tree.loadSound("koyuki");
}catch(e){ Log.err(e); }

// on-screen text lower down (frac = height from the bottom, 0.5 = center) so messages don't collide
function sayLow(text, seconds, frac){
    if(Vars.headless) return;
    try{
        var A = Packages.arc.scene.actions.Actions;
        var t = new Packages.arc.scene.ui.layout.Table(Packages.mindustry.ui.Styles.black3);
        t.touchable = Packages.arc.scene.event.Touchable.disabled;
        t.margin(8).add(text).style(Packages.mindustry.ui.Styles.outlineLabel).labelAlign(Packages.arc.util.Align.center);
        t.update(() => t.setPosition(Core.graphics.getWidth() / 2, Core.graphics.getHeight() * frac, Packages.arc.util.Align.center));
        t.actions(A.fadeOut(seconds, Packages.arc.math.Interp.pow4In), A.remove());
        Core.scene.add(t);
    }catch(e){
        say(text, seconds);   // fallback: centered text
    }
}

// custom burning status: 1 hp/sec, looks like normal fire
const slowBurn = new StatusEffect("slow-burn");
slowBurn.damage = BURN_DAMAGE_PER_SEC / 60;   // damage is per tick
slowBurn.effect = Fx.burning;
slowBurn.color = Color.valueOf("ffc455");

// meteor warning circle + falling rock (color and size per meteor type)
function makeMeteorFx(hex, hotHex, radiusTiles){
    var rpx = radiusTiles * 8;
    return new Effect(METEOR_DELAY, 500, e => {
        Draw.z(Layer.effect);

        // danger zone
        Draw.color(Color.valueOf(hex), 0.12 + 0.18 * e.fin());
        Fill.circle(e.x, e.y, rpx);
        Draw.color(Color.valueOf(hex), 0.5 + 0.5 * Mathf.absin(Time.time, 6, 1));
        Lines.stroke(2);
        Lines.circle(e.x, e.y, rpx);

        // shadow grows as the rock gets closer
        Draw.color(Color.black, 0.3);
        Fill.circle(e.x, e.y, 6 * e.fin());

        // the falling rock
        var h = (1 - e.fin()) * 300;
        Draw.color(Color.valueOf(hotHex), 0.6);
        Lines.stroke(5);
        Lines.line(e.x, e.y + h, e.x, e.y + h + 40);
        Draw.color(Color.valueOf("4a4a4a"));
        Fill.circle(e.x, e.y + h, 7);
        Draw.color(Color.valueOf(hotHex));
        Fill.circle(e.x, e.y + h, 3.5);
        Draw.reset();
    });
}
const redMeteorFx = makeMeteorFx("ff2020", "ff9020", METEOR_RADIUS);
const blueMeteorFx = makeMeteorFx("2080ff", "60c0ff", BLUE_METEOR_RADIUS);

// one meteor: warning circle now, impact after METEOR_DELAY ticks
function dropMeteor(fx, radiusTiles, damage, hitBlocks, x, y, blockDamage){
    try{
        var rpx = radiusTiles * 8;
        fx.at(x, y);
        Time.run(METEOR_DELAY, () => {
            try{
                try{ Fx.explosion.at(x, y); }catch(e){}
                try{ Effect.shake(5, 15, x, y); }catch(e){}

                // player units inside the circle
                Groups.unit.each(u => {
                    if(!u.dead && u.isPlayer() && u.within(x, y, rpx + u.hitSize / 2)){
                        u.damage(damage);
                    }
                });

                // blocks inside the circle (blue meteor only)
                if(hitBlocks){
                    var targets = new Seq();
                    Vars.indexer.allBuildings(x, y, rpx, b => { targets.add(b); });
                    targets.each(b => {
                        if(blockDamage != null){
                            try{ b.damagePierce(blockDamage); }catch(e){ b.damage(blockDamage); }
                        }else{
                            b.damage(damage);
                        }
                    });
                }
            }catch(e){ Log.err(e); }
        });
    }catch(e){ Log.err(e); }
}

// red meteors: METEOR_COUNT around each player, units only
function dropRedMeteors(){
    Groups.player.each(p => {
        if(p.dead()) return;
        var pu = p.unit();
        if(pu == null) return;
        var px = pu.x, py = pu.y;
        for(var i = 0; i < METEOR_COUNT; i++){
            var ox = 0, oy = 0;
            if(i > 0){
                var a = Mathf.random(360);
                var d = Mathf.random(5, 9) * 8;
                ox = Mathf.cosDeg(a) * d;
                oy = Mathf.sinDeg(a) * d;
            }
            var mx = px + ox, my = py + oy;
            Time.run(i * 25, () => dropMeteor(redMeteorFx, METEOR_RADIUS, METEOR_DAMAGE, true, mx, my, RED_METEOR_BLOCK_DAMAGE));
        }
    });
}

// blue meteor: one on each player, hits the player and blocks, small damage
function dropBlueMeteors(){
    Groups.player.each(p => {
        if(p.dead()) return;
        var pu = p.unit();
        if(pu == null) return;
        dropMeteor(blueMeteorFx, BLUE_METEOR_RADIUS, BLUE_METEOR_DAMAGE, true, pu.x, pu.y);
    });
}

// alpha/beta/gamma carry 1 item, every wall has 1 health
function applyStats(){
    try{
        [UnitTypes.alpha, UnitTypes.beta, UnitTypes.gamma].forEach(t => {
            t.itemCapacity = 1;
        });
        Vars.content.blocks().each(b => {
            if(b instanceof Packages.mindustry.world.blocks.defense.Wall){
                b.health = 1;
            }
        });
    }catch(e){ Log.err(e); }
}
Events.on(ContentInitEvent, applyStats);
Events.on(ClientLoadEvent, applyStats);

// every water tile (shallow, deep, sand, tainted...) becomes lava (slag)
function waterToLava(){
    try{
        var w = Vars.world.width(), h = Vars.world.height();
        for(var x = 0; x < w; x++){
            for(var y = 0; y < h; y++){
                var t = Vars.world.tile(x, y);
                if(t != null && t.floor().liquidDrop == Liquids.water){
                    t.setFloor(Blocks.slag);
                }
            }
        }
    }catch(e){ Log.err(e); }
}
// (water -> lava removed: water now becomes brown dirty water, see the added block at the bottom)

// per-world state
var welcomed = false;
var meteorTimer = 0;
var blueTimer = 0;
var shotState = {};
var shotStateCount = 0;
var taxTimer = 0;
Events.on(WorldLoadEvent, e => {
    welcomed = false;
    meteorTimer = 0;
    blueTimer = 0;
    lastHealth = new ObjectFloatMap();
    lastDrillProgress = new ObjectFloatMap();
    drillReal = new ObjectMap();
    drillAssigned = new ObjectMap();
    wasAliveTax = false;
    lastTeam = null;
    taxTimer = 0;
    quakeTimer = 0;
    quakeLeft = 0;
    effectTimer = 0;
});

var miningWarned = false;
var quakeTimer = 0;
var quakeLeft = 0;
var effectTimer = 0;

// earthquake: siren + long screen shake, then some blocks get cracked
function startQuake(){
    quakeLeft = QUAKE_DURATION * 60;
    try{ if(!Vars.headless && sirenSound != null) sirenSound.play(); }catch(e){ reportError("siren", e); }
    sayLow("[scarlet]EARTHQUAKE![]", 3, 0.41);
}

function endQuake(){
    try{
        var victims = [];
        Groups.build.each(b => {
            if(b.block instanceof CoreBlockClass) return;
            if(Mathf.chance(QUAKE_BLOCK_CHANCE)) victims.push(b);
        });
        victims.forEach(b => { if(b.isValid()) b.damage(QUAKE_BLOCK_DAMAGE); });
    }catch(e){ reportError("earthquake", e); }
}

function quakeFrame(){
    if(!Vars.headless){
        var f = quakeLeft / (QUAKE_DURATION * 60);   // 1 -> 0
        Vars.renderer.shake(3 + 7 * f, 12);
    }
    quakeLeft -= Time.delta;
    if(quakeLeft <= 0){
        quakeLeft = 0;
        endQuake();
    }
}

// random status effect on alpha/beta/gamma
function randomEffects(){
    try{
        var pool = [
            [StatusEffects.fast, 15], [StatusEffects.overdrive, 15], [StatusEffects.overclock, 15],
            [StatusEffects.boss, 15], [StatusEffects.shielded, 15], [StatusEffects.freezing, 15],
            [StatusEffects.wet, 15], [StatusEffects.muddy, 15], [StatusEffects.sapped, 15],
            [StatusEffects.tarred, 15], [StatusEffects.slow, 15], [StatusEffects.melting, 5],
            [StatusEffects.unmoving, 3], [StatusEffects.disarmed, 5], [StatusEffects.invincible, 5]
        ].filter(p => p[0] != null);
        if(pool.length == 0) return;
        Groups.unit.each(u => {
            if(u.dead || !isTroll(u)) return;
            var pick = pool[Math.floor(Math.random() * pool.length)];
            u.apply(pick[0], pick[1] * 60);
            if(!Vars.headless && u == Vars.player.unit()){
                sayLow("[accent]RANDOM EFFECT:[] " + (pick[0].localizedName || pick[0].name), 3, 0.20);
            }
        });
    }catch(e){ reportError("random effect", e); }
}

// the player's team (remembered while alive, because a dead player has no team)
var lastTeam = null;
var wasAliveTax = false;

function playerCore(){
    var t = lastTeam != null ? lastTeam : Vars.state.rules.defaultTeam;
    return t.core();
}

// power bills only come in while an active water pump or an active power producer exists
function billsActive(team){
    var found = false;
    try{
        var PumpC = Packages.mindustry.world.blocks.production.Pump;
        var GenC = Packages.mindustry.world.blocks.power.PowerGenerator;
        Groups.build.each(b => {
            if(found || b.team != team) return;
            try{
                if(b.block instanceof PumpC && b.liquidDrop != null && b.efficiency > 0) found = true;
                else if(b.block instanceof GenC && b.productionEfficiency > 0) found = true;
            }catch(e){}
        });
    }catch(e){ Log.err(e); }
    return found;
}

// core tax ("power bills"): the core loses a share of one random resource
function collectTax(){
    try{
        if(Vars.headless || Vars.player == null) return;
        var core = playerCore();
        if(core == null) return;
        if(!billsActive(core.team)) return;
        var list = [];
        Vars.content.items().each(it => { if(core.items.get(it) > 0) list.push(it); });
        if(list.length == 0) return;
        var item = list[Math.floor(Math.random() * list.length)];
        var amt = Math.max(1, Math.floor(core.items.get(item) * TAX_PERCENT));
        core.items.remove(item, amt);
        sayLow("[gold]POWER BILLS COLLECTED:[] -" + amt + " " + item.localizedName, 3, 0.34);
    }catch(e){ reportError("core tax", e); }
}

// death tax: the core pays copper every time the player dies
function deathTax(){
    try{
        var core = playerCore();
        if(core == null) return;
        var n = Math.min(DEATH_TAX, core.items.get(Items.copper));
        if(n > 0 && !Vars.net.client()) core.items.remove(Items.copper, n);
        sayLow(n > 0 ? "[scarlet]DEATH TAX:[] -" + n + " copper"
                     : "[scarlet]DEATH TAX:[] the core is too broke to pay", 3, 0.27);
    }catch(e){ reportError("death tax", e); }
}

// message the first time you place a wall (once per game launch)
var wallMsgShown = false;
Events.on(BlockBuildEndEvent, e => {
    try{
        if(wallMsgShown || e.breaking || e.unit == null) return;
        if(e.team != Vars.player.team() || e.unit != Vars.player.unit()) return;
        if(e.tile.block() instanceof Packages.mindustry.world.blocks.defense.Wall){
            wallMsgShown = true;
            say("[scarlet]we don't fear our enemies[]", 3);
        }
    }catch(err){ Log.err(err); }
});

// ---- images that pop up when a mechanical drill is placed ----
const POP_SHOW = 4;      // seconds fully visible
const POP_FADE = 3;      // seconds of slow fade-out
const POP_GAP = 1;       // seconds between image 1 and image 2
var popActive = 0;

function popImage(spriteName){
    try{
        if(Vars.headless || popActive >= 20) return;
        var region = Core.atlas.find("asian-difficulty-" + spriteName);
        if(region == null || !Core.atlas.isFound(region)) return;

        var sw = Core.scene.getWidth(), sh = Core.scene.getHeight();
        var sz = Math.min(sw, sh) * 0.3;
        var w = sz * (region.width / region.height), h = sz;

        var img = new Packages.arc.scene.ui.Image(region);
        img.setSize(w, h);
        img.setPosition(Mathf.random(0, Math.max(0, sw - w)), Mathf.random(0, Math.max(0, sh - h)));
        img.touchable = Packages.arc.scene.event.Touchable.disabled;   // never blocks taps
        img.color.a = 0;

        popActive++;
        img.actions(
            Packages.arc.scene.actions.Actions.fadeIn(0.2),
            Packages.arc.scene.actions.Actions.delay(POP_SHOW),
            Packages.arc.scene.actions.Actions.fadeOut(POP_FADE),
            Packages.arc.scene.actions.Actions.run(() => { popActive--; }),
            Packages.arc.scene.actions.Actions.remove()
        );
        Core.scene.add(img);
    }catch(e){ Log.err(e); }
}

Events.on(BlockBuildEndEvent, e => {
    try{
        if(e.breaking || e.unit == null) return;
        if(e.team != Vars.player.team() || e.unit != Vars.player.unit()) return;
        if(e.tile.block() == Blocks.mechanicalDrill){
            popImage("dustry1");
            Time.run(POP_GAP * 60, () => popImage("dustry2"));
        }
    }catch(err){ Log.err(err); }
});

// conveyors face the opposite way once built
Events.on(BlockBuildEndEvent, e => {
    try{
        if(e.breaking) return;
        var bd = e.tile.build;
        if(bd == null) return;
        if(!(bd.block instanceof Packages.mindustry.world.blocks.distribution.Conveyor)) return;

        bd.rotation = (bd.rotation + 2) % 4;

        var near = new Seq();
        bd.proximity.each(n => { near.add(n); });
        bd.updateProximity();
        near.each(n => { n.updateProximity(); });
    }catch(err){ Log.err(err); }
});

// small explosion: only damages blocks close by, then kills the unit
function smallBoom(u){
    var x = u.x, y = u.y;
    try{ Fx.explosion.at(x, y); }catch(e){}
    try{ Effect.shake(3, 10, x, y); }catch(e){}
    try{
        var targets = new Seq();
        Vars.indexer.allBuildings(x, y, EXPLOSION_RADIUS * Vars.tilesize, b => { targets.add(b); });
        targets.each(b => { b.damage(EXPLOSION_DAMAGE); });
    }catch(e){ Log.err(e); }
    try{ u.kill(); }catch(e){ Log.err(e); }
}

var lastHealth = new ObjectFloatMap();
var lastDrillProgress = new ObjectFloatMap();
var drillReal = new ObjectMap();       // the item each drill really mines
var drillAssigned = new ObjectMap();   // the item this mod last gave it
var healTick = 0;
var prevBullets = new IntSet();
var mineTimers = {};
var wasMining = {};

Events.run(Trigger.update, () => {
    if(!Vars.state.isGame()) return;

    try{
        // ---- remember the player's team while alive, detect death (alive -> dead) ----
        if(!Vars.headless && Vars.player != null){
            var aliveNow = !Vars.player.dead();
            if(aliveNow) lastTeam = Vars.player.team();
            if(wasAliveTax && !aliveNow) deathTax();
            wasAliveTax = aliveNow;
        }

        // ---- background music: loop while in game, follows the music volume setting ----
        if(!Vars.headless && bgMusic != null){
            try{
                bgMusic.setLooping(true);
                bgMusic.setVolume(Core.settings.getInt("musicvol", 100) / 100);
                if(!bgMusic.isPlaying()) bgMusic.play();
            }catch(e){ Log.err(e); }
        }

        // ---- repair nerf: any block heal gives at most +1 hp (host / singleplayer) ----
        if(!Vars.net.client()){
            healTick++;
            var fresh = (healTick % 300 == 0) ? new ObjectFloatMap() : null;
            var freshProg = (healTick % 300 == 0) ? new ObjectFloatMap() : null;
            var freshReal = (freshProg != null) ? new ObjectMap() : null;
            var freshAssigned = (freshProg != null) ? new ObjectMap() : null;
            Groups.build.each(b => {
                var h = b.health;
                var prev = lastHealth.get(b, h);
                if(h > prev + 1 && !(b.block instanceof Packages.mindustry.world.blocks.ConstructBlock)){
                    h = prev + 1;
                    b.health = h;
                }
                lastHealth.put(b, h);
                if(fresh != null) fresh.put(b, h);

                // wrong drill output: after each item a drill makes, the NEXT one may be sand/scrap
                // (drills hand items straight to conveyors, so we swap what the drill mines instead)
                if(b.block instanceof DrillClass && b.dominantItem != null){
                    try{
                        var cur = b.dominantItem;
                        var assigned = drillAssigned.get(b);
                        var real = drillReal.get(b);
                        if(real == null || assigned == null || cur != assigned){
                            real = cur;                       // the game chose this item itself
                            drillReal.put(b, real);
                        }
                        var pg = b.progress;
                        var lastP = lastDrillProgress.get(b, pg);
                        if(pg < lastP){                        // an item was just produced
                            var next = real;
                            if(Mathf.chance(WRONG_DRILL_CHANCE)){
                                next = Mathf.chance(0.5) ? Items.sand : Items.scrap;
                                if(next == real) next = (next == Items.sand) ? Items.scrap : Items.sand;
                            }
                            b.dominantItem = next;
                            drillAssigned.put(b, next);
                        }
                        lastDrillProgress.put(b, pg);
                        if(freshProg != null){
                            freshProg.put(b, pg);
                            freshReal.put(b, real);
                            var asg = drillAssigned.get(b);
                            if(asg != null) freshAssigned.put(b, asg);
                        }
                    }catch(err){ reportError("drills", err); }
                }
            });
            if(fresh != null) lastHealth = fresh;   // drops buildings that no longer exist
            if(freshProg != null){
                lastDrillProgress = freshProg;
                drillReal = freshReal;
                drillAssigned = freshAssigned;
            }
        }

        // ---- welcome text when the player first spawns in a world ----
        if(!welcomed && !Vars.headless && Vars.player != null && !Vars.player.dead()){
            welcomed = true;
            say("[scarlet]Welcome to hell, sayang[]", 3);
            try{ if(spawnSound != null) spawnSound.play(); }catch(e){ Log.err(e); }
        }

        // ---- red meteors every 30 sec, blue meteor every 60 sec (host / singleplayer) ----
        if(!Vars.state.isPaused() && !Vars.net.client()){
            meteorTimer += Time.delta;
            if(meteorTimer >= METEOR_INTERVAL * 60){
                meteorTimer = 0;
                dropRedMeteors();
            }
            blueTimer += Time.delta;
            if(blueTimer >= BLUE_METEOR_INTERVAL * 60){
                blueTimer = 0;
                dropBlueMeteors();
            }
            taxTimer += Time.delta;
            if(taxTimer >= TAX_INTERVAL * 60){
                taxTimer = 0;
                collectTax();
            }

            quakeTimer += Time.delta;
            if(quakeLeft <= 0 && quakeTimer >= QUAKE_INTERVAL * 60){
                quakeTimer = 0;
                startQuake();
            }
            if(quakeLeft > 0) quakeFrame();

            effectTimer += Time.delta;
            if(effectTimer >= EFFECT_INTERVAL * 60){
                effectTimer = 0;
                randomEffects();
            }
        }

        // ---- bullets: scatter in a random direction (not crux) + shake for alpha/beta/gamma ----
        var next = new IntSet();
        var window = Time.delta * 2.5 + 0.01;
        var shake = false;

        Groups.bullet.each(b => {
            if(b.time > window) return;          // only brand new bullets
            next.add(b.id);
            if(prevBullets.contains(b.id)) return;

            if(b.team != Team.crux){
                // once right, once miss: every second shot of a shooter flies in a random direction
                // (bullets created in the same tick belong to the same shot)
                var oid = -1;
                try{ if(b.owner != null && b.owner.id != null) oid = b.owner.id; }catch(err){}
                var st = shotState[oid];
                if(st == null){
                    if(shotStateCount > 3000){ shotState = {}; shotStateCount = 0; }
                    st = shotState[oid] = {miss: true, t: -100};   // miss:true = last shot was a miss, so the next one is right
                    shotStateCount++;
                }
                if(Time.time - st.t > 2 || Time.time < st.t){
                    st.miss = !st.miss;
                    st.t = Time.time;
                }
                if(st.miss){
                    var ang = Mathf.random(360);
                    b.vel.setAngle(ang);
                    b.rotation(ang);
                }
            }

            var o = b.owner;
            if(o instanceof Unit && isTroll(o)) shake = true;
        });
        prevBullets = next;

        if(shake && !Vars.headless){
            Vars.renderer.shake(SHAKE_INTENSITY, SHAKE_DURATION);
        }

        // ---- alpha/beta/gamma: permanent burning, mining warning, explode on mining ----
        var nextTimers = {};
        var nextMining = {};
        var exploders = [];
        Groups.unit.each(u => {
            if(u.dead || !isTroll(u)) return;

            u.apply(slowBurn, 20);

            var mining = u.mineTile != null;
            nextMining[u.id] = mining;

            // warning when the local player starts mining
            if(mining && !wasMining[u.id] && !miningWarned && !Vars.headless && u == Vars.player.unit()){
                miningWarned = true;   // only shown once per game launch
                say("[scarlet]NO MINING ALLOWED WITHOUT GOVERNMENT PERMISSION[]", 2);
            }

            // mineTimer drops back to 0 each time an ore is actually mined
            var last = mineTimers[u.id];
            nextTimers[u.id] = u.mineTimer;
            if(!Vars.net.client() && mining && last !== undefined && u.mineTimer < last){
                exploders.push(u);
            }
        });
        mineTimers = nextTimers;
        wasMining = nextMining;

        // explode after the loop so nothing gets modified mid-iteration
        exploders.forEach(u => smallBoom(u));
    }catch(e){
        reportError("main loop", e);
    }
});

// alpha/beta/gamma get a little red tint
Events.run(Trigger.postDraw, () => {
    if(Vars.headless || !Vars.state.isGame()) return;
    try{
        Groups.unit.each(u => {
            if(u.dead || !isTroll(u)) return;
            Draw.mixcol(Color.valueOf("ff2020"), 0.3);
            Draw.rect(u.type.region, u.x, u.y, u.rotation - 90);
            Draw.mixcol();
        });
    }catch(e){ Log.err(e); }
});


// =====================================================================
// red UI theme (added): black panels stay, white text/accents -> bright red
// change UI_RED to tweak the color
// =====================================================================
const UI_RED = Color.valueOf("ff1a1a");

function isNearWhite(c){
    return c != null && c.r > 0.85 && c.g > 0.85 && c.b > 0.85;
}

// recolors every white-ish *FontColor on a style object (fontColor, overFontColor, etc.)
function redStyle(style){
    if(style == null) return;
    try{
        var fields = style.getClass().getFields();
        for(var i = 0; i < fields.length; i++){
            var f = fields[i];
            if(!/fontcolor/i.test(String(f.getName()))) continue;
            var v = f.get(style);
            if(v == null){
                if(String(f.getName()) == "fontColor") f.set(style, UI_RED.cpy());
            }else if(isNearWhite(v)){
                f.set(style, UI_RED.cpy());
            }
        }
    }catch(e){ /* not a style object, skip */ }
}

function applyRedTheme(){
    try{
        // accent color: dividers, titles, highlights, selected stuff (edited in place so everything that references it follows)
        Packages.mindustry.graphics.Pal.accent.set(UI_RED);
        Packages.mindustry.graphics.Pal.stat.set(UI_RED);
    }catch(e){ Log.err(e); }

    try{
        // every style in Styles (buttons, labels, dialogs, fields, ...)
        var stylesCls = null;
        try{ stylesCls = java.lang.Class.forName("mindustry.ui.Styles"); }catch(e){ stylesCls = Packages.mindustry.ui.Styles.class; }
        var fields = stylesCls.getDeclaredFields();
        for(var i = 0; i < fields.length; i++){
            try{
                fields[i].setAccessible(true);
                redStyle(fields[i].get(null));
            }catch(e){}
        }
    }catch(e){ Log.err(e); }
}
Events.on(ClientLoadEvent, applyRedTheme);


// =====================================================================
// ADDED FEATURES (everything above this line is untouched)
// =====================================================================

const BLUE = Color.valueOf("4aa8ff");

// ---------------------------------------------------------------------
// 1) crux corvus: laser range +2000 blocks (player corvus stay normal)
// ---------------------------------------------------------------------
const CORVUS_EXTRA_BLOCKS = 2000;
var corvusBaseLen = -1;

function trySet(obj, field, value){
    try{ obj[field] = value; }catch(e){}
}

function patchCruxCorvus(u){
    try{
        if(u.type != UnitTypes.corvus || u.team != Team.crux) return;
        if(corvusBaseLen < 0){
            corvusBaseLen = UnitTypes.corvus.weapons.get(0).bullet.length;
        }
        var ms = u.mounts;
        var need = false;
        for(var i = 0; i < ms.length; i++){
            var b = ms[i].weapon.bullet;
            if(b instanceof Packages.mindustry.entities.bullet.LaserBulletType && b.length < corvusBaseLen + 1) need = true;
        }
        if(!need) return;

        var L = corvusBaseLen + CORVUS_EXTRA_BLOCKS * Vars.tilesize;
        var WM = Packages.mindustry.entities.units.WeaponMount;
        var arr = java.lang.reflect.Array.newInstance(java.lang.Class.forName("mindustry.entities.units.WeaponMount"), ms.length);
        for(var j = 0; j < ms.length; j++){
            var w = ms[j].weapon;
            if(w.bullet instanceof Packages.mindustry.entities.bullet.LaserBulletType){
                var nw = w.copy();
                var nb = w.bullet.copy();
                nb.length = L;
                trySet(nb, "range", L);
                trySet(nb, "maxRange", L);
                trySet(nb, "rangeOverride", L);
                trySet(nb, "drawSize", L * 2);
                nw.bullet = nb;
                arr[j] = new WM(nw);
            }else{
                arr[j] = ms[j];
            }
        }
        u.mounts = arr;
    }catch(e){ reportError("corvus range", e); }
}

var corvusScan = 0;
function corvusFrame(){
    corvusScan += Time.delta;
    if(corvusScan < 20) return;
    corvusScan = 0;
    Groups.unit.each(u => { if(!u.dead) patchCruxCorvus(u); });
}

// ---------------------------------------------------------------------
// 2) reign looks as small as a T2 unit (sprites only, no stat changes)
// ---------------------------------------------------------------------
const REIGN_SCALE = 0.5;   // 1 = vanilla size, 0.5 = about fortress/mace size
var reignShrunk = false;

function shrinkReign(){
    if(reignShrunk || Vars.headless) return;
    try{
        var t = UnitTypes.reign;
        if(t == null) return;
        reignShrunk = true;
        var done = [];
        var AR = Packages.arc.graphics.g2d.TextureAtlas$AtlasRegion;
        var shrink = r => {
            if(r == null || !(r instanceof AR)) return;
            if(String(r.name).indexOf("reign") != 0) return;   // never touch shared/vanilla regions
            for(var i = 0; i < done.length; i++) if(done[i] == r) return;
            done.push(r);
            r.width = Math.max(1, Math.round(r.width * REIGN_SCALE));
            r.height = Math.max(1, Math.round(r.height * REIGN_SCALE));
        };
        [t.region, t.baseRegion, t.legRegion, t.cellRegion, t.outlineRegion].forEach(shrink);
        var seenW = [];
        t.weapons.each(w => {
            for(var i = 0; i < seenW.length; i++) if(seenW[i] == w) return;
            seenW.push(w);
            [w.region, w.outlineRegion, w.heatRegion, w.cellRegion].forEach(shrink);
            // keep guns attached to the smaller body
            w.x *= REIGN_SCALE; w.y *= REIGN_SCALE;
            w.shootX *= REIGN_SCALE; w.shootY *= REIGN_SCALE;
        });
    }catch(e){ Log.err(e); }
}
Events.on(ClientLoadEvent, shrinkReign);

// ---------------------------------------------------------------------
// 4) blue "drop wave" timer + crux T3 units falling from space onto YOU
// ---------------------------------------------------------------------
const DROP_FIRST = 600;        // seconds until the first drop (10 min)
const DROP_INTERVAL = 180;     // seconds between the following drops (3 min)
var dropTarget = DROP_FIRST;
const DROP_COUNT = 2;          // units per player per drop
const DROP_DELAY = 150;        // ticks of falling
const DROP_MAX_ALIVE = 10;     // cap on living dropped units
const DROP_MIN_DIST = 10;      // tiles from the player
const DROP_MAX_DIST = 20;
const DROP_LAND_DAMAGE = 30;   // damage to player units under the landing
const DROP_LAND_RADIUS = 3;    // tiles

var dropTimer = 0;
var hunters = [];
var dropFxCache = {};

Events.on(WorldLoadEvent, e => {
    dropTimer = 0;
    dropTarget = DROP_FIRST;
    hunters = [];
    sporeTick = 0;
    corvusScan = 0;
});

function dropPool(){
    return [UnitTypes.fortress, UnitTypes.quasar, UnitTypes.spiroct, UnitTypes.zenith];
}

function dropFxFor(type){
    if(dropFxCache[type.name] != null) return dropFxCache[type.name];
    var rpx = DROP_LAND_RADIUS * 8;
    var fx = new Effect(DROP_DELAY, 600, e => {
        Draw.z(Layer.effect);
        Draw.color(BLUE, 0.12 + 0.2 * e.fin());
        Fill.circle(e.x, e.y, rpx);
        Draw.color(BLUE, 0.5 + 0.5 * Mathf.absin(Time.time, 6, 1));
        Lines.stroke(2);
        Lines.circle(e.x, e.y, rpx);
        Draw.color(Color.black, 0.3);
        Fill.circle(e.x, e.y, type.hitSize * 0.6 * e.fin());
        var h = (1 - e.fin()) * 450;
        Draw.color(BLUE, 0.5);
        Lines.stroke(4);
        Lines.line(e.x, e.y + h, e.x, e.y + h + 60);
        var r = type.fullIcon;
        var s = 1.5 - 0.5 * e.fin();
        Draw.color();
        Draw.rect(r, e.x, e.y + h, r.width * Draw.scl * s, r.height * Draw.scl * s, 180);
        Draw.reset();
    });
    dropFxCache[type.name] = fx;
    return fx;
}

function findDropSpot(pu, flying){
    for(var i = 0; i < 25; i++){
        var a = Mathf.random(360);
        var d = Mathf.random(DROP_MIN_DIST, DROP_MAX_DIST) * 8;
        var x = pu.x + Mathf.cosDeg(a) * d, y = pu.y + Mathf.sinDeg(a) * d;
        var t = Vars.world.tileWorld(x, y);
        if(t == null) continue;
        if(!flying && (t.solid() || t.floor().isDeep())) continue;
        return [x, y];
    }
    return null;
}

function dropHunter(type, x, y){
    dropFxFor(type).at(x, y);
    Time.run(DROP_DELAY, () => {
        try{
            try{ Fx.explosion.at(x, y); }catch(e){}
            try{ Effect.shake(6, 20, x, y); }catch(e){}
            Groups.unit.each(u => {
                if(!u.dead && u.isPlayer() && u.within(x, y, DROP_LAND_RADIUS * 8 + u.hitSize / 2)) u.damage(DROP_LAND_DAMAGE);
            });
            var un = type.spawn(Team.crux, x, y);
            // plain controller: no walking to your core, we steer it at the player ourselves
            un.controller(new Packages.mindustry.entities.units.AIController());
            hunters.push(un);
        }catch(e){ reportError("drop wave", e); }
    });
}

function dropWave(){
    try{
        var pool = dropPool();
        var alive = 0;
        hunters.forEach(u => { if(u.isValid()) alive++; });
        Groups.player.each(p => {
            if(p.dead()) return;
            var pu = p.unit();
            if(pu == null) return;
            for(var i = 0; i < DROP_COUNT; i++){
                if(alive >= DROP_MAX_ALIVE) return;
                var type = pool[Math.floor(Math.random() * pool.length)];
                var spot = findDropSpot(pu, type.flying);
                if(spot == null) continue;
                alive++;
                dropHunter(type, spot[0], spot[1]);
            }
        });
        sayLow("[#4aa8ff]CRUX DROP PODS INCOMING![]", 3, 0.48);
    }catch(e){ reportError("drop wave", e); }
}

function nearestPlayerUnit(x, y){
    var best = null, bd = 1e12;
    Groups.player.each(p => {
        if(p.dead()) return;
        var pu = p.unit();
        if(pu == null) return;
        var d = pu.dst2(x, y);
        if(d < bd){ bd = d; best = pu; }
    });
    return best;
}

var huntVec = new Packages.arc.math.geom.Vec2();
function huntFrame(){
    var keep = [];
    hunters.forEach(u => {
        if(!u.isValid()) return;
        keep.push(u);
        var tgt = nearestPlayerUnit(u.x, u.y);
        if(tgt == null) return;
        var dist = u.dst(tgt);
        if(dist > u.type.maxRange * 0.7){
            huntVec.set(tgt.x - u.x, tgt.y - u.y).setLength(u.speed());
            u.movePref(huntVec);
        }
        u.lookAt(tgt);
    });
    hunters = keep;
}

function dropSecondsLeft(){
    return Math.max(0, Math.ceil((dropTarget * 60 - dropTimer) / 60));
}

// ---- the blue timer: added as a new row right under the normal wave timer ----
var dropLabel = null, dropOverlay = null, dropMode = 0, waveAnchor = null, hudTick = 0, hudErrShown = false;

function findWaveLabel(){
    var prefix = String(Core.bundle.get("wave")).replace(/\{0\}[\s\S]*$/, "").trim();
    if(prefix.length == 0) return null;
    var found = null;
    var LabelC = Packages.arc.scene.ui.Label;
    var GroupC = Packages.arc.scene.Group;
    var walk = e => {
        if(found != null || e == null) return;
        if(e instanceof LabelC){
            if(e != dropLabel && e.visible && e.parent != null){
                var s = String(e.getText()).replace(/\[[^\]]*\]/g, "").trim();
                if(s.indexOf(prefix) == 0){
                    var ly = e.localToStageCoordinates(new Packages.arc.math.geom.Vec2(0, 0)).y;
                    if(ly > Core.scene.getHeight() * 0.7) found = e;   // the real wave panel is at the top
                }
            }
            return;
        }
        if(e instanceof GroupC && e.visible){
            var ch = e.getChildren();
            for(var i = 0; i < ch.size; i++) walk(ch.get(i));
        }
    };
    walk(Vars.ui.hudGroup != null ? Vars.ui.hudGroup : Core.scene.root);
    return found;
}

function topAnchor(wl){
    var el = wl;
    while(el.parent != null && el.parent != Vars.ui.hudGroup && el.parent != Core.scene.root){
        var p = el.parent;
        if(p.getWidth() > Core.graphics.getWidth() * 0.7 || p.getHeight() > Core.graphics.getHeight() * 0.5) break;
        el = p;
    }
    return el;
}

// the wave panel itself = the highest small table (with a background) around the wave label
function panelAnchor(wl){
    // the wave panel = the NEAREST table with a background around the wave label that is
    // panel-sized (wide-ish, not tall); the big layout tables further up are ignored
    var TableC = Packages.arc.scene.ui.layout.Table;
    var W = Core.scene.getWidth(), H = Core.scene.getHeight();
    var el = wl;
    while(el != null && el != Vars.ui.hudGroup && el != Core.scene.root){
        if(el instanceof TableC && el.getBackground() != null && el.getWidth() > W * 0.25 && el.getHeight() < H * 0.2) return el;
        el = el.parent;
    }
    return null;
}

function anchorOk(el){
    try{
        if(el == null || el.parent == null || !el.visible || el.getHeight() <= 0) return false;
        var v = el.localToStageCoordinates(new Packages.arc.math.geom.Vec2(0, 0));
        return v.y > Core.scene.getHeight() * 0.7 && v.y < Core.scene.getHeight() && v.x >= 0 && v.x < Core.scene.getWidth() * 0.8;
    }catch(e){ return false; }
}

var waveLabelRef = null;
var dropFill = null, dropCell = null, dropPad = -1;

function hudFrame(){
    if(Vars.headless || Core.scene == null) return;
    try{
        if(dropLabel == null){
            dropLabel = new Packages.arc.scene.ui.Label("", Packages.mindustry.ui.Styles.outlineLabel);
            dropLabel.setFontScale(0.9);
        }
        var sec = dropSecondsLeft();
        dropLabel.setText("[#4aa8ff]Crux drop in " + Math.floor(sec / 60) + ":" + ("0" + (sec % 60)).slice(-2) + "[]");

        var host = Vars.ui.hudGroup != null ? Vars.ui.hudGroup : Core.scene.root;

        // a full-screen table pinned to the TOP-LEFT; the timer is one cell in it,
        // pushed down by (distance from the top of the screen to the bottom of the wave panel)
        if(dropFill == null){
            dropOverlay = new Packages.arc.scene.ui.layout.Table(Packages.mindustry.ui.Styles.black6);
            dropOverlay.margin(6);
            dropOverlay.add(dropLabel);
            dropFill = new Packages.arc.scene.ui.layout.Table();
            dropFill.setFillParent(true);
            dropFill.touchable = Packages.arc.scene.event.Touchable.disabled;
            dropFill.top().left();
            dropCell = dropFill.add(dropOverlay).padTop(215 / (Core.graphics.getHeight() / host.getHeight()));
            host.addChild(dropFill);
        }

        hudTick++;
        if(hudTick % 20 == 1){
            try{
                if(!anchorOk(waveAnchor)){
                    var wl = findWaveLabel();
                    waveLabelRef = wl;
                    waveAnchor = wl != null ? panelAnchor(wl) : null;
                }
                var ratio = Core.graphics.getHeight() / host.getHeight();
                var pad;
                if(anchorOk(waveAnchor)){
                    var v = waveAnchor.localToStageCoordinates(new Packages.arc.math.geom.Vec2(0, 0));
                    pad = host.getHeight() - v.y + 2;
                }else if(waveLabelRef != null && waveLabelRef.parent != null){
                    // no panel found: go below the wave text plus the panel's bottom padding
                    var lv = waveLabelRef.localToStageCoordinates(new Packages.arc.math.geom.Vec2(0, 0));
                    pad = host.getHeight() - lv.y + 45 / ratio;
                }else{
                    pad = 215 / ratio;
                }
                if(pad > 0 && pad < host.getHeight() * 0.3 && Math.abs(pad - dropPad) > 1){
                    dropPad = pad;
                    dropCell.padTop(pad);
                    dropFill.invalidateHierarchy();
                }
            }catch(e2){}
        }

        dropFill.setVisible(Vars.state.isGame() && !Vars.state.isEditor());
    }catch(e){
        if(!hudErrShown){ hudErrShown = true; say("[scarlet]drop timer error:[] " + e, 8); }
    }
}
Events.run(Trigger.update, hudFrame);

// ---------------------------------------------------------------------
// 6) spore pods on any conveyor damage nearby blocks by 1 hp
// ---------------------------------------------------------------------
const SPORE_RADIUS = 2;      // tiles
const SPORE_DAMAGE = 1;      // hp
const SPORE_INTERVAL = 60;   // ticks (1 hit per second per spore-carrying conveyor)
var sporeTick = 0;
var sporeTinted = [];

function sporeFrame(){
    sporeTick += Time.delta;
    if(sporeTick < SPORE_INTERVAL) return;
    sporeTick = 0;
    try{
        var ConvC = Packages.mindustry.world.blocks.distribution.Conveyor;
        var StackC = Packages.mindustry.world.blocks.distribution.StackConveyor;
        var carriers = [];
        var tintNew = [];
        Groups.build.each(b => {
            if((b.block instanceof ConvC || b.block instanceof StackC) && b.items != null && b.items.has(Items.sporePod)) carriers.push(b);
        });
        carriers.forEach(c => {
            var victims = new Seq();
            Vars.indexer.allBuildings(c.x, c.y, SPORE_RADIUS * Vars.tilesize, b => { if(b != c) victims.add(b); });
            victims.each(b => {
                if(!b.isValid()) return;
                tintNew.push(b);
                try{ b.damagePierce(SPORE_DAMAGE); }catch(e){ b.damage(SPORE_DAMAGE); }
            });
        });
        sporeTinted = tintNew;
    }catch(e){ reportError("spore", e); }
}

// ---- main loop for the added features ----
Events.run(Trigger.update, () => {
    if(!Vars.state.isGame() || Vars.state.isPaused() || Vars.net.client()) return;
    try{
        corvusFrame();
        sporeFrame();
        dropTimer += Time.delta;
        if(dropTimer >= dropTarget * 60){
            dropTimer = 0;
            dropTarget = DROP_INTERVAL;
            dropWave();
        }
        huntFrame();
    }catch(e){ reportError("added features", e); }
});

// ---------------------------------------------------------------------
// 5) your logo replaces the game logo in the main menu
//    (sprites-override/ui/logo.png does it, this is a backup way)
// ---------------------------------------------------------------------
function swapLogo(){
    try{
        var r = Core.atlas.find("asian-difficulty-logo");
        if(r != null && Core.atlas.isFound(r)) Core.atlas.addRegion("logo", r);
    }catch(e){ Log.err(e); }
}
Events.on(ClientLoadEvent, swapLogo);

// ---------------------------------------------------------------------
// 7) cute main-menu background shake
// ---------------------------------------------------------------------
const MENU_SHAKE_X = 1.4;   // world units (background is zoomed ~4x+)
const MENU_SHAKE_Y = 1.1;
var shakenRenderer = null;
var shakeErrShown = false;

function findField(cls, name){
    while(cls != null){
        try{ var f = cls.getDeclaredField(name); f.setAccessible(true); return f; }catch(e){}
        cls = cls.getSuperclass();
    }
    return null;
}

function installMenuShake(){
    if(Vars.headless) return;
    try{
        var mf = Vars.ui.menufrag;
        if(mf == null) return;
        var rf = findField(mf.getClass(), "renderer");
        if(rf == null) throw "no renderer field";
        var rend = rf.get(mf);
        if(rend == null || rend == shakenRenderer) return;
        var cf = findField(rend.getClass(), "camera");
        if(cf == null) throw "no camera field";
        var cam = extend(Packages.arc.graphics.Camera, {
            update(){
                var t = Date.now() / 1000;
                var ox = Math.sin(t * 2.1) * MENU_SHAKE_X + Math.sin(t * 17) * 0.25;
                var oy = Math.cos(t * 2.7) * MENU_SHAKE_Y + Math.sin(t * 23) * 0.2;
                var w0 = this.width, h0 = this.height;
                this.position.add(ox, oy);
                this.width = w0 * 0.96;    // tiny zoom so no map edge shows
                this.height = h0 * 0.96;
                this.super$update();
                this.width = w0;
                this.height = h0;
                this.position.sub(ox, oy);
            }
        });
        cf.set(rend, cam);
        shakenRenderer = rend;
    }catch(e){
        if(!shakeErrShown){ shakeErrShown = true; Log.err(e); say("[scarlet]menu shake error:[] " + e, 8); }
    }
}
Events.on(ClientLoadEvent, installMenuShake);
Events.on(StateChangeEvent, e => { try{ if(String(e.to) == "menu") installMenuShake(); }catch(err){} });
if(!Vars.headless) Packages.arc.util.Timer.schedule(() => installMenuShake(), 1, 1);

// ---------------------------------------------------------------------
// 8) leaving the map (dark border area): 4 crux alphas hunt you,
//    they vanish as soon as you are back inside
// ---------------------------------------------------------------------
const GUARD_COUNT = 4;
const DARK_MARGIN = 2;      // tiles from the map edge that count as the dark area
var guards = [];
var guardActive = false;
var guardCheck = 0;

function inDarkZone(u){
    var tx = u.x / Vars.tilesize, ty = u.y / Vars.tilesize;
    var x0 = 0, y0 = 0, x1 = Vars.world.width(), y1 = Vars.world.height();
    var r = Vars.state.rules;
    if(r.limitMapArea){ x0 = r.limitX; y0 = r.limitY; x1 = x0 + r.limitWidth; y1 = y0 + r.limitHeight; }
    return tx < x0 + DARK_MARGIN || ty < y0 + DARK_MARGIN || tx > x1 - DARK_MARGIN || ty > y1 - DARK_MARGIN;
}

function guardFrame(){
    guardCheck += Time.delta;
    if(guardCheck < 10) return;
    guardCheck = 0;
    try{
        var outUnit = null;
        Groups.player.each(p => {
            if(outUnit != null || p.dead()) return;
            var pu = p.unit();
            if(pu != null && inDarkZone(pu)) outUnit = pu;
        });
        if(outUnit != null && !guardActive){
            guardActive = true;
            for(var i = 0; i < GUARD_COUNT; i++){
                var a = Mathf.random(360), d = Mathf.random(6, 10) * 8;
                var x = outUnit.x + Mathf.cosDeg(a) * d, y = outUnit.y + Mathf.sinDeg(a) * d;
                var un = UnitTypes.alpha.spawn(Team.crux, x, y);
                un.controller(new Packages.mindustry.entities.units.AIController());
                guards.push(un);
                try{ Fx.explosion.at(x, y); }catch(e){}
            }
            sayLow("[scarlet]TURN BACK![]", 3, 0.55);
        }else if(outUnit == null && guardActive){
            guardActive = false;
            guards.forEach(u => {
                if(u.isValid()){
                    try{ Fx.explosion.at(u.x, u.y); }catch(e){}
                    u.remove();
                }
            });
            guards = [];
        }
    }catch(e){ reportError("map edge guards", e); }
}

Events.on(WorldLoadEvent, e => { guards = []; guardActive = false; guardCheck = 0; });

Events.run(Trigger.update, () => {
    if(!Vars.state.isGame() || Vars.state.isPaused() || Vars.net.client()) return;
    guardFrame();
    var keep = [];
    guards.forEach(u => {
        if(!u.isValid()) return;
        keep.push(u);
        var tgt = nearestPlayerUnit(u.x, u.y);
        if(tgt == null) return;
        if(u.dst(tgt) > u.type.maxRange * 0.7){
            huntVec.set(tgt.x - u.x, tgt.y - u.y).setLength(u.speed());
            u.movePref(huntVec);
        }
        u.lookAt(tgt);
    });
    guards = keep;
});


// ---------------------------------------------------------------------
// 9) radioactive generators: differential generator, steam generator and
//    thorium reactor hurt nearby blocks and tint them yellow.
//    spore conveyors tint nearby blocks purple (see sporeFrame above)
// ---------------------------------------------------------------------
const RAD_RADIUS = 4;      // tiles
const RAD_DAMAGE = 1;      // hp per hit
const RAD_INTERVAL = 60;   // ticks between hits
const RAD_COLOR = Color.valueOf("ffe600");
const SPORE_COLOR = Color.valueOf("b36bff");
var radTick = 0;
var radTinted = [];

function isRadSource(blk){
    return blk == Blocks.differentialGenerator || blk == Blocks.steamGenerator || blk == Blocks.thoriumReactor;
}

function radFrame(){
    radTick += Time.delta;
    if(radTick < RAD_INTERVAL) return;
    radTick = 0;
    try{
        var sources = [];
        Groups.build.each(b => { if(isRadSource(b.block)) sources.push(b); });
        var seen = new ObjectSet();
        var victims = [];
        sources.forEach(sr => {
            Vars.indexer.allBuildings(sr.x, sr.y, RAD_RADIUS * Vars.tilesize, b => {
                if(isRadSource(b.block)) return;
                if(seen.add(b)) victims.push(b);
            });
        });
        victims.forEach(b => {
            if(!b.isValid()) return;
            try{ b.damagePierce(RAD_DAMAGE); }catch(e){ b.damage(RAD_DAMAGE); }
        });
        radTinted = victims;
    }catch(e){ reportError("radiation", e); }
}

Events.run(Trigger.update, () => {
    if(!Vars.state.isGame() || Vars.state.isPaused() || Vars.net.client()) return;
    radFrame();
});

Events.on(WorldLoadEvent, e => { radTinted = []; sporeTinted = []; radTick = 0; });

Events.run(Trigger.postDraw, () => {
    if(Vars.headless || !Vars.state.isGame()) return;
    try{
        var pulse = 0.28 + 0.1 * Mathf.absin(Time.time, 30, 1);
        radTinted.forEach(b => {
            if(!b.isValid()) return;
            Draw.color(RAD_COLOR, pulse);
            Fill.rect(b.x, b.y, b.block.size * Vars.tilesize, b.block.size * Vars.tilesize);
        });
        sporeTinted.forEach(b => {
            if(!b.isValid()) return;
            Draw.color(SPORE_COLOR, pulse);
            Fill.rect(b.x, b.y, b.block.size * Vars.tilesize, b.block.size * Vars.tilesize);
        });
        Draw.reset();
    }catch(e){ Log.err(e); }
});


// ---------------------------------------------------------------------
// 10) delete cores in survival: double-tap a core of yours (or tap it
//     while in break mode / holding shift) and confirm
// ---------------------------------------------------------------------
var lastCoreTapTime = 0, lastCoreTapId = -1;

function deleteCore(b){
    try{
        if(b == null || !b.isValid()) return;
        var team = b.team, reqs = b.block.requirements, x = b.x, y = b.y;
        try{ Fx.explosion.at(x, y); }catch(e){}
        try{ Effect.shake(6, 20, x, y); }catch(e){}
        b.tile.setNet(Blocks.air);
        var other = team.core();
        if(other != null){
            for(var i = 0; i < reqs.length; i++){
                var amt = Math.floor(reqs[i].amount * Vars.state.rules.deconstructRefundMultiplier);
                var room = other.getMaximumAccepted(reqs[i].item) - other.items.get(reqs[i].item);
                amt = Math.max(0, Math.min(amt, room));
                if(amt > 0) other.items.add(reqs[i].item, amt);
            }
        }
    }catch(e){ reportError("delete core", e); }
}

Events.on(TapEvent, e => {
    try{
        if(Vars.headless || e.player != Vars.player || Vars.state.isEditor() || Vars.net.client()) return;
        var b = e.tile == null ? null : e.tile.build;
        if(b == null || !(b.block instanceof CoreBlockClass) || b.team != Vars.player.team()) return;

        var now = Time.millis();
        var dbl = (lastCoreTapId == b.id && now - lastCoreTapTime < 700);
        lastCoreTapId = b.id;
        lastCoreTapTime = now;

        var breaking = false;
        try{ breaking = Vars.control.input.isBreaking(); }catch(err){}
        var shift = false;
        try{ shift = Core.input.keyDown(Packages.arc.input.KeyCode.shiftLeft); }catch(err){}
        if(!(dbl || breaking || shift)) return;
        lastCoreTapId = -1;

        var last = b.team.cores().size <= 1;
        Vars.ui.showConfirm("Delete core", last ? "This is your LAST core, deleting it ends the game. Delete anyway?" : "Delete this core? You get a part of its cost back.", () => deleteCore(b));
    }catch(err){ reportError("core tap", err); }
});

// ---------------------------------------------------------------------
// 11) water is brown "dirty water" now + Water Filter block
//     (every step is guarded: a failing step is reported on screen instead of
//      silently stopping the rest of the mod)
// ---------------------------------------------------------------------
const DIRTY_COLOR = Color.valueOf("7a5230");
var initErrors = [];
function guard(label, fn){
    try{ fn(); }catch(e){ initErrors.push(label + ": " + e); try{ Log.err(e); }catch(x){} }
}

var dirtyWater = null;
guard("liquid", () => {
    dirtyWater = new Liquid("dirty-water", DIRTY_COLOR);
});
guard("liquid text", () => {
    dirtyWater.localizedName = "Dirty Water";
    dirtyWater.description = "Muddy water. Needs to be cleaned in a water filter.";
    dirtyWater.alwaysUnlocked = true;
    dirtyWater.viscosity = 0.6;
    dirtyWater.heatCapacity = 0.2;   // worse coolant than water (0.4)
});

var waterFilter = null;
var filterBottomDraw = null;
guard("block", () => {
    waterFilter = extend(Packages.mindustry.world.blocks.production.GenericCrafter, "water-purifier", {});
});
guard("block text", () => {
    waterFilter.localizedName = "Water Filter";
    waterFilter.description = "Cleans dirty water into normal water.";
    waterFilter.alwaysUnlocked = true;
});
guard("block cost/menu", () => {
    var cost = ItemStack.with(Items.copper, 50, Items.lead, 30, Items.graphite, 20);
    try{
        waterFilter.requirements(Category.crafting, cost);
    }catch(e){
        waterFilter.requirements = cost;
        waterFilter.category = Category.crafting;
    }
    waterFilter.category = Category.crafting;
    waterFilter.buildVisibility = Packages.mindustry.world.meta.BuildVisibility.shown;
});
guard("block stats", () => {
    waterFilter.size = 2;
    waterFilter.hasPower = true;
    waterFilter.hasItems = false;
    waterFilter.hasLiquids = true;
    waterFilter.rotate = false;
    waterFilter.solid = true;
    waterFilter.outputsLiquid = true;
    waterFilter.liquidCapacity = 24;
});
guard("block output", () => {
    waterFilter.outputLiquid = new LiquidStack(Liquids.water, 12 / 60);
});
guard("block input", () => {
    waterFilter.consumeLiquid(dirtyWater, 12 / 60);
});
guard("block power", () => {
    waterFilter.consumePower(0.5);
});
guard("block drawer", () => {
    var DM = Packages.mindustry.world.draw;
    filterBottomDraw = new DM.DrawRegion("-bottom");
    waterFilter.drawer = new DM.DrawMulti(
        filterBottomDraw,
        new DM.DrawLiquidTile(dirtyWater),
        new DM.DrawLiquidTile(Liquids.water),
        new DM.DrawDefault()
    );
});

function findRegion(n){
    var r = Core.atlas.find("asian-difficulty-" + n);
    if(r != null && Core.atlas.isFound(r)) return r;
    r = Core.atlas.find(n);
    if(r != null && Core.atlas.isFound(r)) return r;
    return null;
}

// textures are set by hand so they show up whatever name the game gave the block
function applyFilterSprites(){
    guard("sprites", () => {
        if(Vars.headless || waterFilter == null) return;
        var top = findRegion("water-purifier");
        var bottom = findRegion("water-purifier-bottom");
        var icon = findRegion("water-purifier-icon");
        if(top != null) waterFilter.region = top;
        if(icon != null){ waterFilter.uiIcon = icon; waterFilter.fullIcon = icon; }
        if(bottom != null && filterBottomDraw != null) filterBottomDraw.region = bottom;
        var di = findRegion("dirtywater-icon");
        if(di != null && dirtyWater != null){ dirtyWater.uiIcon = di; dirtyWater.fullIcon = di; }
    });
}

var dirtyApplied = false;
function applyDirtyWater(){
    if(dirtyApplied || dirtyWater == null) return;
    guard("floors", () => {
        var FloorC = Packages.mindustry.world.blocks.environment.Floor;
        var n = 0;
        Vars.content.blocks().each(b => {
            if(b instanceof FloorC && b.liquidDrop == Liquids.water){
                b.liquidDrop = dirtyWater;
                try{ b.liquidMultiplier = b.liquidMultiplier * 0.7; }catch(e){}   // pumps give less dirty water
                n++;
                try{ b.mapColor.set(DIRTY_COLOR); }catch(e){}
            }
        });
        if(n > 0) dirtyApplied = true;
    });
}
Events.on(ContentInitEvent, applyDirtyWater);
Events.on(ClientLoadEvent, () => { applyDirtyWater(); applyFilterSprites(); });
Events.on(WorldLoadEvent, e => { applyDirtyWater(); });

var initErrShown = false;
function showInitErrors(){
    if(initErrShown || initErrors.length == 0 || Vars.headless) return;
    initErrShown = true;
    Log.err("AsianDustry water setup problems: " + initErrors.join(" | "));
}
Events.on(WorldLoadEvent, e => { Time.run(240, showInitErrors); });

// ---- brown tint over every water tile (indexed once per world, drawn per visible chunk) ----
const WCHUNK = 16;
var waterChunks = {};
function indexWater(){
    try{
        waterChunks = {};
        if(dirtyWater == null) return;
        var w = Vars.world.width(), h = Vars.world.height();
        for(var x = 0; x < w; x++){
            for(var y = 0; y < h; y++){
                var t = Vars.world.tile(x, y);
                if(t != null && t.floor().liquidDrop == dirtyWater){
                    var k = Math.floor(x / WCHUNK) * 10000 + Math.floor(y / WCHUNK);
                    if(waterChunks[k] == null) waterChunks[k] = [];
                    waterChunks[k].push(x, y);
                }
            }
        }
    }catch(e){ Log.err(e); }
}
Events.on(WorldLoadEvent, indexWater);

Events.run(Trigger.draw, () => {
    if(Vars.headless || !Vars.state.isGame()) return;
    try{
        var cam = Core.camera;
        var ts = Vars.tilesize;
        var cx0 = Math.max(0, Math.floor((cam.position.x - cam.width / 2) / ts / WCHUNK));
        var cx1 = Math.floor((cam.position.x + cam.width / 2) / ts / WCHUNK);
        var cy0 = Math.max(0, Math.floor((cam.position.y - cam.height / 2) / ts / WCHUNK));
        var cy1 = Math.floor((cam.position.y + cam.height / 2) / ts / WCHUNK);
        Draw.z(5);
        Draw.color(DIRTY_COLOR, 0.6);
        for(var cx = cx0; cx <= cx1; cx++){
            for(var cy = cy0; cy <= cy1; cy++){
                var list = waterChunks[cx * 10000 + cy];
                if(list == null) continue;
                for(var i = 0; i < list.length; i += 2){
                    Fill.rect(list[i] * ts, list[i + 1] * ts, ts, ts);
                }
            }
        }
        Draw.reset();
    }catch(e){ Log.err(e); }
});


// ---------------------------------------------------------------------
// 12) "mi bombo" plays when a conveyor is placed (build start; the build end
//     plays it too if the start was missed)
// ---------------------------------------------------------------------
var bomboSound = null;
var lastBomboTime = 0;
var bomboSeen = {};

function getBombo(){
    if(bomboSound == null){
        try{ bomboSound = Vars.tree.loadSound("mi-bombo"); }catch(e){ reportError("mi bombo sound", e); }
    }
    return bomboSound;
}
getBombo();

function isConveyorBlock(blk){
    return blk instanceof Packages.mindustry.world.blocks.distribution.Conveyor ||
           blk instanceof Packages.mindustry.world.blocks.distribution.StackConveyor;
}

function playBombo(tile){
    var snd = getBombo();
    if(snd == null) return;
    var now = Time.millis();
    var key = tile.pos();
    if(bomboSeen[key] != null && now - bomboSeen[key] < 15000) return;   // already played for this placement
    bomboSeen[key] = now;
    if(now - lastBomboTime < 50) return;   // tiny throttle for dragged lines
    lastBomboTime = now;
    snd.play();
}

Events.on(BlockBuildBeginEvent, e => {
    try{
        if(Vars.headless || e.breaking) return;
        var bd = e.tile.build;
        var cur = (bd instanceof Packages.mindustry.world.blocks.ConstructBlock$ConstructBuild) ? bd.current : e.tile.block();
        if(cur != null && isConveyorBlock(cur)) playBombo(e.tile);
    }catch(err){ Log.err(err); }
});
Events.on(BlockBuildEndEvent, e => {
    try{
        if(Vars.headless || e.breaking) return;
        if(isConveyorBlock(e.tile.block())) playBombo(e.tile);
    }catch(err){ Log.err(err); }
});
Events.on(WorldLoadEvent, e => { bomboSeen = {}; });

// ---------------------------------------------------------------------
// 14) every ground / air / naval factory blows up 10 minutes after it was
//     placed: the "change da world" banner shows for 2 s, fades slowly, and the
//     factory explodes right when the fade starts
// ---------------------------------------------------------------------
const FACTORY_FUSE = 300;   // seconds between placing a factory and the banner + explosion (5 min)
const CDW_HOLD = 2;         // seconds fully visible
const CDW_FADE = 2.5;       // seconds of slow fade-out
const CDW_WIDTH = 0.5;      // banner width as a share of the screen width
var cdwTable = null, cdwImg = null, cdwT = -1;

function isFactoryBlock(blk){
    return blk == Blocks.groundFactory || blk == Blocks.airFactory || blk == Blocks.navalFactory;
}

var cdwStartMs = 0;

function hideChangeWorld(){
    cdwT = -1;
    try{ if(cdwTable != null){ cdwTable.clearActions(); cdwTable.remove(); } }catch(e){}
    cdwTable = null;
    cdwImg = null;
}

function showChangeWorld(){
    try{
        if(Vars.headless) return;
        var reg = findRegion("change-da-world");
        if(reg == null) return;
        hideChangeWorld();
        cdwImg = new Packages.arc.scene.ui.Image(new Packages.arc.scene.style.TextureRegionDrawable(reg));
        cdwTable = new Packages.arc.scene.ui.layout.Table();
        cdwTable.setFillParent(true);
        cdwTable.touchable = Packages.arc.scene.event.Touchable.disabled;
        cdwTable.center();
        var w = Core.scene.getWidth() * CDW_WIDTH;
        cdwTable.add(cdwImg).size(w, w * reg.height / reg.width);
        Core.scene.root.addChild(cdwTable);
        cdwStartMs = Date.now();
        cdwT = 0;
        // scene actions: wait, fade slowly, remove (does not depend on any other timer)
        try{
            var A = Packages.arc.scene.actions.Actions;
            cdwTable.addAction(A.sequence(A.delay(CDW_HOLD), A.fadeOut(CDW_FADE), A.remove()));
        }catch(e){ Log.err(e); }
    }catch(e){
        Log.err(e);
        hideChangeWorld();
    }
}

// backup: by the real clock the banner is removed after hold + fade, whatever else happens
Events.run(Trigger.update, () => {
    if(cdwTable == null) return;
    try{
        if(Date.now() - cdwStartMs > (CDW_HOLD + CDW_FADE) * 1000 + 300) hideChangeWorld();
    }catch(e){ hideChangeWorld(); }
});
Timer_ok: {
    if(!Vars.headless) Packages.arc.util.Timer.schedule(() => {
        try{ if(cdwTable != null && Date.now() - cdwStartMs > (CDW_HOLD + CDW_FADE) * 1000 + 300) hideChangeWorld(); }catch(e){}
    }, 1, 1);
}
Events.on(WorldLoadEvent, e => hideChangeWorld());

Events.on(BlockBuildEndEvent, e => {
    try{
        if(e.breaking || !isFactoryBlock(e.tile.block())) return;
        var bd = e.tile.build;
        // every placed factory gets its own 10 minute fuse
        Time.run(FACTORY_FUSE * 60, () => {
            try{
                if(bd == null || !bd.isValid()) return;   // already gone
                showChangeWorld();
                Time.run(CDW_HOLD * 60, () => {
                    try{
                        if(bd != null && bd.isValid()){
                            try{ Fx.explosion.at(bd.x, bd.y); }catch(err){}
                            try{ Effect.shake(8, 25, bd.x, bd.y); }catch(err){}
                            bd.kill();
                        }
                    }catch(err){ Log.err(err); }
                });
            }catch(err){ Log.err(err); }
        });
    }catch(err){ Log.err(err); }
});

// ---------------------------------------------------------------------
// 13) main menu music: vanilla menu track removed, "shady girls" or
//     "mischievous step" (random each time) plays instead
// ---------------------------------------------------------------------
var menuTracks = [];
try{ menuTracks.push(Vars.tree.loadMusic("shady-girls")); }catch(e){ Log.err(e); }
try{ menuTracks.push(Vars.tree.loadMusic("mischievous-step")); }catch(e){ Log.err(e); }

function pickMenuMusic(){
    try{
        if(Vars.headless || menuTracks.length == 0) return;
        var t = menuTracks[Math.floor(Math.random() * menuTracks.length)];
        Packages.mindustry.gen.Musics.menu = t;
    }catch(e){ Log.err(e); }
}
Events.on(ClientLoadEvent, pickMenuMusic);
Events.on(StateChangeEvent, e => { try{ if(String(e.to) == "menu") pickMenuMusic(); }catch(err){} });
